import test from 'node:test';
import assert from 'node:assert/strict';
import {totals,emptyTotals,previousMonth,validate,plan,sample,change,isDate,defaults,financialSummary,financialPeriods,withCRM,manualOnly,withBusiness,revenueAttribution,migrateLegacyCRM,validClient,commissionSplit,sumCommissionSplits} from '../public/model.js';
import {server} from '../server.js';
const record=(date,values={})=>({id:crypto.randomUUID(),date,...emptyTotals(),notes:'',...values});
test('Totali mensili: somma aggiornamenti nello stesso giorno, separa periodi e gestisce cambio anno',()=>{
 const records=[record('2026-11-01',{contacts:5,revenue:200.5}),record('2026-11-01',{contacts:3,revenue:100}),record('2026-10-31',{contacts:99})];
 assert.equal(totals(records,'2026-11').contacts,8);assert.equal(totals(records,'2026-11').revenue,300.5);assert.equal(previousMonth('2026-01'),'2025-12');assert.equal(change(10,0),null);assert.equal(change(15,10),50);
});
test('Piano: distingue obiettivi raggiunti, ritardi, periodi conclusi e obiettivi disattivati',()=>{
 const month='2026-11',now=new Date('2026-11-15T12:00:00'),goals={[month]:{...defaults,contacts:60,appointments:0}},records=[record('2026-11-01',{contacts:10,sales:2})];
 const actions=plan(records,goals,month,now),contacts=actions.find(x=>x.key==='contacts');assert.equal(contacts.state,'behind');assert.equal(contacts.gap,50);assert.equal(contacts.remaining,16);assert.equal(actions.find(x=>x.key==='sales').state,'done');assert.equal(actions.some(x=>x.key==='appointments'),false);
 assert.equal(plan(records,goals,month,new Date('2026-12-01T12:00:00')).find(x=>x.key==='contacts').state,'closed');assert.deepEqual(plan(records,{},month,now),[]);
});
test('Backup e date: rifiuta corruzione, numeri negativi o conteggi frazionari',()=>{
 const data=sample(new Date('2026-11-02T12:00:00'));assert.deepEqual(validate(JSON.parse(JSON.stringify(data))),data);assert.equal(isDate('2026-02-30'),false);assert.equal(isDate('2024-02-29'),true);
 for(const value of [-1,.5,NaN]){const bad=structuredClone(data);bad.records[0].contacts=value;assert.throws(()=>validate(bad));}
 const bad=structuredClone(data);bad.records.push(bad.records[0]);assert.throws(()=>validate(bad));
});
test('HTTP: applicazione e moduli disponibili; file esterni e richieste di scrittura rifiutati',async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));try{const base=`http://127.0.0.1:${server.address().port}`;for(const path of ['/','/style.css','/app.js','/model.js'])assert.equal((await fetch(base+path)).status,200);assert.equal((await fetch(base+'/%2e%2e%2fpackage.json')).status,403);assert.equal((await fetch(base,{method:'POST'})).status,405);}finally{await new Promise(r=>server.close(r))}
});

test('Controllo economico: aggregazioni giorno/mese/anno, frequenze non moltiplicate e centesimi',()=>{
 const records=[record('2026-11-01',{revenue:1000,expenses:100}),record('2026-11-02',{revenue:500}),record('2025-11-01',{revenue:9999})];
 const expenses=[{id:'monthly',date:'2026-11-01',amount:250,description:'Affitto',category:'Affitto e utenze',frequency:'Mensile'},{id:'annual',date:'2026-11-02',amount:50,description:'Licenza',category:'Software e servizi',frequency:'Annuale'}];
 const month=financialSummary(records,expenses,'2026-11');assert.equal(month.revenue,1500);assert.equal(month.expenses,400);assert.equal(month.margin,747.5);assert.equal(month.marginPercent,747.5/1500*100);assert.equal(month.categories.reduce((n,x)=>n+x.amount,0),400);
 assert.equal(financialSummary(records,expenses,'2026-11-02').margin,332.5);assert.equal(financialSummary(records,expenses,'2026').margin,747.5);assert.equal(financialPeriods(records,expenses,'year','2026').length,12);assert.equal(financialPeriods(records,expenses,'month','2024-02').length,29);
 const rounded=financialSummary([record('2026-11-01',{revenue:.1}),record('2026-11-01',{revenue:.2})],[],'2026-11');assert.equal(rounded.revenue,.3);
});
test('Margine negativo, incassi zero e percentuale annuale ricalcolata sui totali',()=>{
 const records=[record('2026-01-01',{revenue:100,expenses:150}),record('2026-02-01',{revenue:900,expenses:100})];assert.equal(financialSummary(records,[],'2026-01').margin,-73.5);assert.equal(financialSummary(records,[],'2026-01').marginPercent,-73.5);assert.equal(financialSummary(records,[],'2026').marginPercent,51.5);assert.equal(financialSummary([record('2026-03-01',{expenses:80})],[],'2026-03').marginPercent,null);
});
test('Backup nuovi e precedenti: preserva spese dettagliate e rifiuta importi e frequenze non validi',()=>{
 const data=sample(new Date('2026-11-02T12:00:00'));assert.deepEqual(validate(JSON.parse(JSON.stringify(data))),data);const legacy=structuredClone(data);delete legacy.expenseEntries;assert.doesNotThrow(()=>validate(legacy));
 for(const amount of [0,-1,Infinity]){const bad=structuredClone(data);bad.expenseEntries[0].amount=amount;assert.throws(()=>validate(bad));}
 const bad=structuredClone(data);bad.expenseEntries[0].frequency='Settimanale';assert.throws(()=>validate(bad));
});

test('Collegamento CRM: vendite previste, incassi parziali, spese, modifiche e cancellazioni senza duplicazioni',()=>{
 const base={version:1,records:[],goals:{},expenseEntries:[]};
 const crm={version:1,clients:[],deals:[{id:'sale1',title:'Casa Palermo',date:'2026-11-01',status:'Conclusa',commission:5000}],cashEntries:[]};
 let state=withCRM(base,crm);assert.equal(totals(state.records,'2026-11').sales,1);assert.equal(financialSummary(state.records,state.expenseEntries,'2026-11').revenue,0);
 crm.cashEntries=[{id:'payment1',type:'income',date:'2026-11-01',amount:2000,description:'Acconto',dealId:'sale1',category:'Altro',frequency:'Una tantum'},{id:'payment2',type:'income',date:'2026-11-02',amount:1000,description:'Secondo acconto',dealId:'sale1',category:'Altro',frequency:'Una tantum'},{id:'expense1',type:'expense',date:'2026-11-02',amount:400,description:'Portale',dealId:'',category:'Pubblicità e portali',frequency:'Mensile'}];
 state=withCRM(base,crm);const summary=financialSummary(state.records,state.expenseEntries,'2026-11');assert.equal(summary.revenue,3000);assert.equal(summary.expenses,400);assert.equal(summary.margin,1895);assert.equal(totals(state.records,'2026-11').sales,1);
 assert.deepEqual(withCRM(state,crm),state);assert.equal(manualOnly(state).records.length,0);assert.equal(manualOnly(state).expenseEntries.length,0);
 crm.cashEntries[0].amount=1500;state=withCRM(base,crm);assert.equal(financialSummary(state.records,state.expenseEntries,'2026-11').revenue,2500);
 crm.cashEntries=[];crm.deals[0].status='Annullata';state=withCRM(base,crm);assert.equal(totals(state.records,'2026-11').sales,0);assert.equal(financialSummary(state.records,state.expenseEntries,'2026-11').revenue,0);
 assert.throws(()=>withCRM(base,{version:1,clients:[],cashEntries:[{id:'bad'}]}));
});

const nativeClient=(id='client1',source='Social')=>({id,firstName:'Anna',lastName:'Rossi',address:'Via Roma 10',city:'Palermo',postalCode:'90100',province:'PA',phone:'3331234567',email:'anna@example.com',source,sourceDetails:'Instagram',notes:''});
test('Anagrafica e provvigioni: campi completi, attribuzione per cliente/fonte e totali riconciliati',()=>{
 const client=nativeClient();assert.equal(validClient(client),true);assert.equal(validClient({...client,lastName:''}),false);assert.equal(validClient({...client,source:'Non valida'}),false);
 const raw={version:1,records:[record('2026-11-01',{revenue:100})],expenseEntries:[],goals:{},clients:[client],deals:[],cashEntries:[{id:'p1',type:'income',date:'2026-11-02',amount:2000,description:'Acconto provvigione',clientId:client.id,dealId:'',category:'Altro',frequency:'Una tantum'}]};assert.doesNotThrow(()=>validate(raw));const computed=withBusiness(raw);assert.equal(financialSummary(computed.records,computed.expenseEntries,'2026-11').revenue,2100);assert.deepEqual(withBusiness(computed),computed);
 const attribution=revenueAttribution(raw,'2026-11');assert.equal(attribution.total,2100);assert.equal(attribution.byClient[0].name,'Anna Rossi');assert.equal(attribution.bySource[0].source,'Social');assert.equal(attribution.bySource[0].amount,2000);assert.equal(attribution.unattributed,100);assert.equal(revenueAttribution(raw,'2026').total,2100);
 const bad=structuredClone(raw);bad.cashEntries[0].clientId='missing';assert.throws(()=>validate(bad));assert.deepEqual(validate(JSON.parse(JSON.stringify(raw))),raw);
});
test('Migrazione del precedente archivio: nessuna perdita, niente duplicati e anagrafiche incomplete esplicite',()=>{
 const raw={version:1,records:[],expenseEntries:[],goals:{}};const crm={version:1,clients:[{id:'old',name:'Maria De Luca',phone:'3330000000',email:'maria@example.com',city:'Roma'}],deals:[{id:'d1',title:'Casa Roma',clientId:'old',date:'2026-11-01',status:'Conclusa',commission:3000}],cashEntries:[{id:'p1',type:'income',date:'2026-11-02',amount:1000,description:'Acconto',dealId:'d1',category:'Altro',frequency:'Una tantum'}]};const migrated=migrateLegacyCRM(raw,crm);assert.equal(migrated.clients[0].firstName,'Maria De Luca');assert.equal(migrated.clients[0].legacyIncomplete,true);assert.equal(migrated.cashEntries[0].clientId,migrated.clients[0].id);assert.deepEqual(migrateLegacyCRM(migrated,crm),migrated);assert.equal(financialSummary(withBusiness(migrated).records,[],'2026-11').revenue,1000);assert.doesNotThrow(()=>validate(migrated));
});

test('Quote fisse RE/MAX: 4000 → 400 Italia → 3600 → 540 Platinum → 3060 netto',()=>{
 assert.deepEqual(commissionSplit(4000),{gross:4000,italiaFee:400,afterItalia:3600,platinumFee:540,netRevenue:3060});
 const records=[record('2026-11-01',{revenue:4000})],expenses=[{id:'e1',date:'2026-11-01',amount:500,description:'Affitto',category:'Affitto e utenze',frequency:'Mensile'}];const summary=financialSummary(records,expenses,'2026-11');assert.equal(summary.margin,2560);assert.equal(summary.marginPercent,64);assert.equal(summary.totalDeductions,1440);assert.equal(summary.expenses,500);assert.equal(summary.netRevenue,3060);
 assert.equal(financialSummary(records,[],'2026-11').margin,3060);assert.equal(financialSummary(records,[],'2026-11').marginPercent,76.5);
 assert.throws(()=>commissionSplit(-1));assert.throws(()=>commissionSplit(Infinity));
});
test('Quote arrotondate per incasso: somme coerenti per giorno, mese, anno e fonte',()=>{
 const records=[record('2026-11-01',{revenue:.05}),record('2026-11-02',{revenue:.05})];assert.equal(sumCommissionSplits([.05,.05]).netRevenue,.06);assert.equal(commissionSplit(.10).netRevenue,.08);const monthly=financialSummary(records,[],'2026-11'),annual=financialSummary(records,[],'2026');assert.equal(monthly.netRevenue,.06);assert.equal(annual.netRevenue,.06);const days=financialPeriods(records,[],'month','2026-11');assert.equal(days.reduce((n,d)=>n+Math.round(d.netRevenue*100),0),6);
 const client=nativeClient(),raw={version:1,records:[],expenseEntries:[],goals:{},clients:[client],deals:[],cashEntries:[.05,.05].map((amount,i)=>({id:'p'+i,type:'income',date:'2026-11-01',amount,description:'Provvigione',clientId:client.id,dealId:'',category:'Altro',frequency:'Una tantum'}))};const attribution=revenueAttribution(raw,'2026-11');assert.equal(attribution.byClient[0].netRevenue,.06);assert.equal(attribution.bySource[0].netRevenue,.06);assert.equal(attribution.netTotal,.06);
});
