"""Crea il pacchetto di installazione locale Windows basato su Edge/Chrome."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import subprocess
import sys
root=Path(__file__).resolve().parent.parent
subprocess.run([sys.executable,str(root/'scripts'/'build_portable.py')],check=True)
source=root/'windows'
files=['INSTALLA-TEAM-GUZZETTA.cmd','RIMUOVI-TEAM-GUZZETTA.cmd','TeamGuzzetta.ico','LEGGIMI-WINDOWS.txt']
for name in files:
 if not (source/name).is_file():
  raise SystemExit('File richiesto mancante: '+name)
archive=root.parent/'TEAM-GUZZETTA-INSTALLAZIONE-WINDOWS.zip'
with ZipFile(archive,'w',ZIP_DEFLATED) as z:
 for name in files:z.write(source/name,Path('TeamGuzzetta-Installa')/name)
 z.write(root.parent/(root.name+'-APRI.html'),Path('TeamGuzzetta-Installa')/'TEAM-GUZZETTA-STATISTICHE-APRI.html')
with ZipFile(archive) as z:assert z.testzip() is None
print('Installazione Windows:',archive)
