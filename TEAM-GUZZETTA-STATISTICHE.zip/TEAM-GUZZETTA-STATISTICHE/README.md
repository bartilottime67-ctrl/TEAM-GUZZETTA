# Team Guzzetta · Business Intelligence

Programma economico con anagrafiche clienti, provenienza delle provvigioni, vendite, incassi, spese e report professionali. Il precedente gestionale incorporato è stato rimosso: tutte le operazioni avvengono nelle sezioni native dell'applicazione.

## Avvio

Node.js 20 o successivo, senza dipendenze da installare:

```sh
npm start
```

Porta predefinita 3001, configurabile con `PORT`. Sviluppo: `npm run dev`. Verifiche: `npm test`.

Per la versione HTML autonoma e lo ZIP: `python3 scripts/build_portable.py`. Il file `TEAM-GUZZETTA-STATISTICHE-APRI.html` viene generato accanto alla cartella del progetto e non carica moduli o un gestionale esterno.

## Clienti

La sezione Clienti contiene nome, cognome, indirizzo completo, telefono, email e provenienza obbligatori. Città, CAP, provincia, dettaglio della fonte/segnalatore e note completano l'anagrafica.

Le fonti sono Social, Conoscenze, Capitale sociale, Immobili e Altro. Ricerca e filtro consentono di trovare un cliente anche attraverso i contatti o la provenienza. La scheda mostra tutti i dati e le provvigioni effettivamente incassate nello storico.

Un cliente con vendite o pagamenti collegati non può essere eliminato: questo preserva la provenienza degli incassi. Si possono correggere i suoi dati. La provenienza usata nei report è quella attualmente associata all'anagrafica; una correzione della fonte aggiorna anche il raggruppamento degli incassi storici.

## Vendite e provvigioni

- Una vendita Conclusa incrementa il numero delle operazioni alla data indicata. La provvigione prevista non è denaro incassato.
- Vendite e provvigioni → Registra incasso richiede un cliente con anagrafica completa. Si può collegare anche una vendita; il cliente della vendita deve coincidere con quello del pagamento.
- Ogni acconto è un pagamento distinto, alla data effettiva. Le statistiche sommano automaticamente i movimenti, senza riepiloghi giornalieri aggiuntivi.
- Vendite e provvigioni → Registra spesa registra data, importo, descrizione, categoria e frequenza. Il modulo spese è dedicato alle uscite e non richiede cliente o vendita; non applica le quote RE/MAX.
- Modifiche ed eliminazioni ricalcolano tutti i periodi. Eliminare una vendita conserva i pagamenti e il riferimento al loro cliente, rimuovendo solo il legame alla pratica.

Il Registro risultati resta disponibile per attività e dati storici. Non reinserire nel registro manuale gli importi già presenti nei movimenti. I dati derivati da vendite e pagamenti sono identificati come “Da movimenti” e si correggono nella sezione Vendite e provvigioni.

### Incassi e spese separati

In Vendite e provvigioni i pulsanti “Registra incasso” (blu) e “Registra spesa” (bordò) aprono moduli distinti. Non è necessario scegliere il tipo da un modulo misto. Titolo, etichetta entrata/uscita, campi e pulsante di salvataggio identificano l'operazione. La modifica mantiene il tipo originario.

Puoi registrare incassi e spese con la stessa data: sono movimenti distinti, con colonne “Incasso lordo” e “Spesa pagata”, segno e indicatore testuale. Il programma somma le entrate e sottrae le uscite nel margine; applica Italia e Platinum soltanto agli incassi. La Panoramica non presenta “Registra risultati” e il Controllo economico non presenta “Nuovo movimento”.

## Quote fisse RE/MAX

Inserire sempre la **provvigione lorda**, prima delle trattenute. Il programma applica automaticamente, in sequenza:

1. RE/MAX Italia: 10% del lordo.
2. RE/MAX Platinum: 15% del residuo dopo Italia.
3. Netto RE/MAX = lordo − quota Italia − quota Platinum.
4. Margine effettivo = netto RE/MAX − altre spese registrate.

Esempio: 4.000 € lordi → 400 € Italia → residuo 3.600 € → 540 € Platinum → netto 3.060 €. Con 500 € di altre spese il margine effettivo è 2.560 € (64% sul lordo).

Ogni quota viene arrotondata ai centesimi per singolo incasso; nei riepiloghi vengono sommate le quote dei singoli pagamenti. Anche gli acconti e i dati storici seguono questa regola. Le quote sono derivate e non creano nuove registrazioni: non reinserirle tra le altre spese. Modificare, eliminare o ripristinare un incasso ricalcola gli importi senza duplicazioni.

Le quote sono fisse nel programma, sulla base delle percentuali richieste. Il prospetto le deduce dal margine senza attestare che siano già state effettivamente pagate. I dati già registrati vengono ricalcolati come lordi: eventuali importi precedentemente inseriti già al netto vanno corretti nel movimento di origine.

## Analisi economica

Il Controllo economico presenta Giorno, Mese e Anno, con incassi, spese, margine in euro, margine percentuale, confronto con il periodo precedente e composizione delle spese. La sezione “Da dove arrivano le provvigioni” riconcilia gli incassi per cliente e fonte con il totale del periodo, distinguendo lordo, Italia, Platinum e netto dopo RE/MAX.

- Margine effettivo (€) = provvigioni lorde − Italia (10%) − Platinum (15% dopo Italia) − altre spese.
- Margine (%) = margine effettivo / provvigioni lorde × 100. Con incassi zero si mostra “n.d.”.
- La percentuale totale si ricalcola sui totali: non è la media dei singoli giorni.
- I calcoli economici sommano centesimi interi.
- Una spesa mensile o annuale conta una sola volta alla data del pagamento. La frequenza è descrittiva: non genera rate future né ripartizioni per competenza.
- Il totale comprende anche le spese già presenti nel precedente Registro risultati, senza duplicarle automaticamente.

Le provvigioni e le altre spese seguono le date dei pagamenti; le quote RE/MAX sono invece deduzioni automatiche. Il prospetto non è un bilancio fiscale o un utile netto. IVA, imposte, ammortamenti e altri costi sono inclusi solo se registrati. Giorni senza dati mostrano zero, senza attestare l'assenza di movimenti. I periodi in corso possono essere incompleti. Gli incassi storici del Registro risultati privi di cliente sono esposti separatamente come “Incassi storici senza cliente”, senza attribuire loro una fonte inventata.

## Obiettivi e statistiche operative

Sono disponibili grafici giornalieri, confronto mensile e un piano “Cosa fare” basato sugli obiettivi del mese e sui giorni di calendario trascorsi. Un obiettivo zero è disattivato. Le fasi operative mostrano volumi del periodo, non la conversione degli stessi clienti. Le indicazioni sono regole di calcolo con suggerimenti generali, da valutare sulle pratiche reali.

## Report PDF e CSV per professionisti

“Stampa / Salva PDF” apre la stampa del browser in A4 orizzontale: selezionare Salva come PDF. Il prospetto include periodo, data di elaborazione, grafici, tabelle, categorie, provvigioni per cliente/provenienza e criteri di calcolo. Non include indirizzi, telefono ed email delle anagrafiche. I dati di esempio sono dichiarati dimostrativi.

“Esporta CSV / Excel” genera CSV UTF-8 con BOM, punto e virgola e decimali con virgola, apribile con Excel. Include tutti i periodi, totali, categorie, clienti e fonti degli incassi. Non è un file XLSX. I giorni vuoti sono inizialmente nascosti solo a video, ma presenti in PDF e CSV. I report mostrano lordo, Italia, Platinum, netto RE/MAX, altre spese e margine effettivo. Per cliente e fonte, il netto RE/MAX precede le altre spese generali dell’agenzia.

Palette: champagne e dorato chiaro, bordò e blu luminoso per gli incassi.

## Archivio e backup

Tutti i dati sono nel `localStorage` del browser, in un unico archivio. Il backup contiene clienti, vendite, pagamenti, inserimenti storici e obiettivi; i valori derivati e le quote RE/MAX non vengono salvati una seconda volta. Il ripristino chiede conferma prima di sostituire l'archivio e ricalcola i prospetti senza duplicazioni. Esportare regolarmente: la cancellazione dei dati del browser può comportarne la perdita.

La prima apertura di questa versione recupera, se presente nella stessa origine del browser, l'archivio della precedente integrazione. La vecchia copia non viene cancellata o modificata. Nome e cognome dei vecchi dati non vengono separati arbitrariamente: l'anagrafica importata è segnalata “Da completare” e richiede verifica, indirizzo e fonte. Gli incassi già presenti restano nei totali; nuovi incassi richiedono anagrafiche complete. Un pagamento storico senza cliente è segnalato come da associare. Il vecchio archivio non viene più riletto come fonte attiva: la migrazione è una tantum, con identificativi stabili.

Si possono ripristinare anche vecchi backup CRM da Clienti → Ripristina backup. Porte, browser o file diversi non condividono necessariamente lo stesso archivio; per trasferirlo usare il backup. Non ci sono account, lettura bancaria o database multiutente. La condivisione avviene con i report esportati.

I dati iniziali sono fittizi. “Inizia con i tuoi dati” rimuove statistiche e obiettivi dimostrativi e le anagrafiche/pagamenti di esempio non modificati. Le anagrafiche dimostrative cui siano stati collegati movimenti effettivi sono conservate. I movimenti reali non vengono rimossi da questa operazione.

## Grafica personalizzata Team Guzzetta

L'interfaccia usa un'identità coordinata champagne, dorato e bordò: simbolo della chiave con profilo di casa, illustrazione immobiliare dedicata, menu suddiviso per area di lavoro, schede economiche con importi più leggibili e moduli distinti per entrate e uscite. L'impaginazione si adatta a desktop, tablet e smartphone. La grafica è inclusa nel file HTML autonomo e nei report PDF senza caricare font o immagini da servizi esterni. Le animazioni rispettano la preferenza del dispositivo per il movimento ridotto.

Per aggiornare una copia Windows già in uso, esportare prima il backup e ripristinarlo nella nuova copia qualora il browser non ritrovi automaticamente l'archivio.

## Identità Chiave

La palette aggiornata usa dorato più scuro e bronzo, con scritte bordò e blu luminoso solo per gli incassi. Il simbolo G è stato sostituito da una chiave geometrica dal profilo di casa, ripresi nel menu, nell’intestazione e nell’icona del browser.

## Installazione locale su Windows

`python3 scripts/build_windows.py` crea `TEAM-GUZZETTA-INSTALLAZIONE-WINDOWS.zip` accanto al progetto. Richiede l'icona già presente in `windows/TeamGuzzetta.ico`; non aggiunge dipendenze all'applicazione.

L'utente estrae tutto lo ZIP e avvia `INSTALLA-TEAM-GUZZETTA.cmd`. Lo script cerca Edge e, in alternativa, Chrome, copia l'HTML in `%LOCALAPPDATA%\TeamGuzzetta`, crea le icone sul Desktop e nel menu Start e un comando di rimozione. Non richiede privilegi di amministratore e non modifica le politiche di esecuzione di Windows.

L'app viene avviata tramite `--app` in una finestra dedicata del browser, con `--user-data-dir` nella cartella `ProfiloApp`. È un'app locale ospitata dal browser, non un eseguibile nativo indipendente. Funziona offline dopo il download. L'aggiornamento conserva percorso e profilo, con copia del precedente HTML; la rimozione elimina programma e icone ma conserva dati e versione precedente.

I dati della vecchia copia HTML non vengono trasferiti automaticamente: esportare il backup dal vecchio programma e ripristinarlo nella nuova app. Il pacchetto e gli script sono verificabili, ma l'installazione e le API Windows vanno provate su un PC Windows reale. Le restrizioni aziendali possono impedire gli script o l'uso di profili browser dedicati.

### Diagnosi dell'installazione Windows

L'installer conserva l'output in `%TEMP%\TeamGuzzetta-installazione.log` e, quando fallisce, tenta di copiarlo in `ERRORE-INSTALLAZIONE.txt` accanto al file CMD. Cinque fasi identificano file del pacchetto, browser, cartella utente, copia programma e icone. I messaggi di errore non vengono soppressi. La sintassi del nucleo PowerShell è stata verificata con il parser ufficiale di PowerShell 7.4.6; le operazioni Windows richiedono comunque prova sul PC dell'utente. La copia `windows/installer-core.ps1` contiene il nucleo controllato: il CMD lo esegue come comando, senza cambiare le politiche di esecuzione del sistema.
