"""Genera HTML autonomo e ZIP, senza dipendenze aggiuntive."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import re
root = Path(__file__).resolve().parent.parent
public = root / 'public'
html = (public / 'index.html').read_text().replace('<link rel="stylesheet" href="/style.css">', '<style>' + (public / 'style.css').read_text() + '</style>')
model = (public / 'model.js').read_text().replace('export const ', 'const ').replace('export function ', 'function ')
app = re.sub(r'^import .*?;\n', '', (public / 'app.js').read_text(), count=1).replace('crypto.randomUUID()', 'newId()')
helper = "function newId(){if(globalThis.crypto?.randomUUID)return globalThis.crypto.randomUUID();const a=new Uint8Array(16);globalThis.crypto.getRandomValues(a);return Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');}\n"
html = html.replace('<script type="module" src="/app.js"></script>', '<script>'+model+'\n'+helper+app+'</script>')
output = root.parent / (root.name + '-APRI.html')
output.write_text(html)
archive = root.parent / (root.name + '.zip')
with ZipFile(archive, 'w', ZIP_DEFLATED) as z:
 for f in sorted(root.rglob('*')):
  if f.is_file() and not any(x in {'.git','node_modules','.env','__pycache__'} for x in f.relative_to(root).parts):
   z.write(f, Path(root.name) / f.relative_to(root))
 z.write(output, Path(root.name) / output.name)
 for ext in ('pdf','csv'):
  example = root.parent / ('Team-Guzzetta-Report-ESEMPIO.' + ext)
  if example.is_file():
   z.write(example, Path(root.name) / 'esempi' / example.name)
print('Creati:', output, archive)
