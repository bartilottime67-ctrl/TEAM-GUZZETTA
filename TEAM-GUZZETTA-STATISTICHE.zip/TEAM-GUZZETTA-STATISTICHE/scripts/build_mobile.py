"""Prepara docs/ per GitHub Pages e l'installazione Android via Chrome."""
from pathlib import Path
import hashlib
import json
import re
import shutil
root=Path(__file__).resolve().parent.parent
repo=root.parent/'TEAM-GUZZETTA'
destination=repo/'docs'
destination.mkdir(exist_ok=True)
for name in ['app.js','model.js','style.css']:
 shutil.copy2(root/'public'/name,destination/name)
html=(root/'public'/'index.html').read_text().replace('href="/style.css"','href="./style.css"').replace('src="/app.js"','src="./app.js"')
html=html.replace('<title>','<link rel="manifest" href="./manifest.webmanifest"><meta name="mobile-web-app-capable" content="yes"><meta name="application-name" content="Team Guzzetta"><title>',1)
banner='''<section id="android-install" class="install-banner" hidden><div><strong>Team Guzzetta, anche sul telefono.</strong><span id="offline-status">Preparazione della modalità offline… Intanto puoi continuare a usare l’app.</span></div><button class="btn primary" id="install-app">Come installare</button></section><section id="mobile-update" class="install-banner update-banner" hidden><div><strong>È disponibile una nuova versione.</strong><span>Salva eventuali moduli aperti, poi aggiorna l’app.</span></div><button class="btn" id="update-app">Aggiorna</button></section>'''
html=html.replace('<main id="main"></main>',banner+'<main id="main"></main>')
help='''<dialog id="install-help"><div class="dialog-head"><h2>Installa su Android</h2><button class="icon-btn" id="close-install-help" aria-label="Chiudi istruzioni">×</button></div><ol class="install-steps"><li>Apri questo indirizzo in <strong>Google Chrome</strong>, con la connessione attiva.</li><li>Tocca il menu <strong>⋮</strong> in alto a destra.</li><li>Scegli <strong>Aggiungi a schermata Home</strong> e poi <strong>Installa</strong>. Il nome può variare con la versione di Chrome.</li><li>Apri <strong>Team Guzzetta</strong> dall’icona sul telefono.</li></ol><p class="hint">I dati restano su questo dispositivo. Per portare quelli del PC, trasferisci il backup JSON sul telefono e usa Clienti → Ripristina backup. PC e telefono non si sincronizzano automaticamente.</p></dialog>'''
html=html.replace('<script type="module" src="./app.js"></script>',help+'<script type="module" src="./app.js"></script><script type="module" src="./pwa.js"></script>')
(destination/'index.html').write_text(html)
shutil.copy2(root/'mobile'/'pwa.js',destination/'pwa.js')
styles='''\n.install-banner{display:flex;align-items:center;gap:16px;justify-content:space-between;margin:20px 38px 0;padding:17px 20px;border:1px solid #e1c892;border-radius:12px;background:#fff3d9;color:#93405b}.install-banner strong{display:block;font-size:12px}.install-banner span{display:block;font-size:10px;line-height:1.9;margin-top:5px;max-width:720px}.install-banner .btn{flex-shrink:0}.update-banner{background:#fff9ed}.install-steps{padding-left:22px;font-size:13px;color:#98455f;line-height:1.9}.install-steps li{margin:13px 0}@media(max-width:820px){.install-banner{margin:15px 14px 0;padding:15px;gap:13px;align-items:flex-start;flex-wrap:wrap}.install-banner .btn{font-size:11px}.install-banner span{font-size:10px}}@media print{.install-banner,#install-help{display:none!important}}\n'''
with (destination/'style.css').open('a') as file:file.write(styles)
assets=destination/'assets';assets.mkdir(exist_ok=True)
for name in ['icon-192.png','icon-512.png']:
 source=root/'mobile'/'assets'/name
 if not source.is_file():raise SystemExit('Icona mancante: '+str(source))
 shutil.copy2(source,assets/name)
manifest={'id':'./','name':'Team Guzzetta · Controllo economico','short_name':'Team Guzzetta','description':'Clienti, provvigioni, spese e margini con quote RE/MAX. Archivio locale.','lang':'it','start_url':'./','scope':'./','display':'standalone','background_color':'#f8f4eb','theme_color':'#c59a42','icons':[{'src':'./assets/icon-192.png','sizes':'192x192','type':'image/png','purpose':'any maskable'},{'src':'./assets/icon-512.png','sizes':'512x512','type':'image/png','purpose':'any maskable'}]}
(destination/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
shell=['./index.html','./style.css','./app.js','./model.js','./pwa.js','./manifest.webmanifest','./assets/icon-192.png','./assets/icon-512.png']
version=hashlib.sha256(b''.join((destination/name[2:]).read_bytes() for name in shell)).hexdigest()[:16]
sw="""const VERSION=__VERSION__;
const PREFIX='team-guzzetta-mobile:'+self.registration.scope+':';
const CACHE=PREFIX+VERSION;
const SHELL=__SHELL__;
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE);await cache.addAll(SHELL.map(path=>new Request(new URL(path,self.registration.scope),{cache:'reload'})));})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith(PREFIX)&&key!==CACHE)await caches.delete(key);await self.clients.claim();})()));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin||!url.href.startsWith(self.registration.scope))return;
 if(event.request.mode==='navigate'){event.respondWith((async()=>{const cache=await caches.open(CACHE);return await cache.match(new URL('./index.html',self.registration.scope))||fetch(event.request);})());return;}
 const paths=new Set(SHELL.map(path=>new URL(path,self.registration.scope).pathname));if(!paths.has(url.pathname))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE);url.search='';return await cache.match(url.href)||fetch(event.request);})());
});
""".replace('__VERSION__',json.dumps(version)).replace('__SHELL__',json.dumps(shell))
(destination/'sw.js').write_text(sw)
(destination/'.nojekyll').write_text('')
print('Android PWA pronta in',destination,'versione',version)
